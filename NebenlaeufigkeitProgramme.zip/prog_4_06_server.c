/* Beispielprogramm 4.6 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Socket-Kommunikation in der UNIX-Domain mit Streams: Server */

#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <stdio.h>

main() {

 int server_acc_sock;  /* Deskr. des Sockets fuer Verbindungsaufbau */
 int server_comm_sock;
        /* Deskr. des Sockets fuer die Kommunikation mit dem Client */

 struct sockaddr server_addr, client_addr;

 char buffer[256];  /* zur Aufnahme der empfangenen Nachricht */
 int addr_len, err; /* Hilfsvariable */

 server_acc_sock = socket(AF_UNIX,SOCK_STREAM,0);
 server_addr.sa_family = AF_UNIX;
 strcpy(server_addr.sa_data,"ServerSocket");
 bind(server_acc_sock,&server_addr,sizeof(struct sockaddr));

 /* Einrichten der Warteschlange fuer Verbindungsaufbauwuensche */
 listen(server_acc_sock,1);

 /* Warten, bis ein Verbindungsaufbauwunsch eintrifft, und
    Akzeptieren dieses Wunschs. Ab dann "steht" die Verbindung */
 addr_len = sizeof(client_addr);
 server_comm_sock = accept(server_acc_sock,&client_addr,&addr_len);

 /* Entgegennehmen einer Nachricht des Clients */
 read(server_comm_sock,buffer,sizeof(buffer));
 printf("\nServer hat gelesen: %s\n\n",buffer);

 /* Senden einer Rueckmeldung */
 write(server_comm_sock,"Nachricht ist angekommen",25);

 /* Schlie�en der Sockets */
 close(server_acc_sock);
 close(server_comm_sock);

}
