/* Beispielprogramm 5.2 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Kontaktieren eines WWW-Servers ueber Sockets */

#include <netdb.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#define BUFSIZE 8192

main() {

 int sock;  /* ID der eigenen Socket */
 int error, numbytes, fd;  /* Hilfsvariablen */
 char buffer[BUFSIZE]; /* Zwischenspeicher f�r eintreffende Daten */
 struct sockaddr_in server_addr;  /* Server-Adresse */
 struct hostent *host; /* zur Verarbeitung einer symbol. Adresse */

 /* Erzeugung einer Stream-Socket in der Internet-Domain */
 sock = socket(AF_INET,SOCK_STREAM,0);

 /* Zusammenstellen der Server-Adresse */
 server_addr.sin_family = AF_INET;
 host = gethostbyname("www.nt.fh-koeln.de");
 bcopy(host->h_addr,&server_addr.sin_addr,host->h_length);
 server_addr.sin_port = htons(80);

 /* Verbindung der Socket mit der Socket des Servers */
 error = connect(sock, (struct sockaddr *) &server_addr, sizeof(struct sockaddr));
 if (error == -1) exit(-1);

 /* �bertragung des HTTP-GET-Befehls */
 write(sock,"GET /vogt/index.html HTTP/1.1\n",30);
 write(sock,"Host: www.nt.fh-koeln.de\n",25);
 write(sock,"Connection: Close\n\n",19);

 /* Erzeugung einer lokalen Datei zur Aufnahme der Web-Seite */
 fd = open("webpage.html",O_CREAT|O_WRONLY,0777);
 /* Blockweises Einlesen und Speichern der Seite (vergleiche 4.2.4.5) */
 do {
  numbytes = read(sock,buffer,BUFSIZE);
  write(fd,buffer,numbytes);
 } while (numbytes>0);

 close(fd);

}