/* Beispielprogramm 2.12 aus                          */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Warten auf die Terminierung eines Threads mit join() */

// Klasse f�r den Thread, auf dessen Ende gewartet werden soll:
// Der Thread blockiert sich f�r zwei Sekunden und terminiert dann.

class BeispielThread extends Thread {

 public void run() {
  System.out.println("Thread: Ich laufe an");
  try {
   sleep(2000);
  } catch (InterruptedException e) {}
  System.out.println("Thread: Ich terminiere");
 }
 
}

// Hauptprogramm, dessen Thread auf den Beispiel-Thread wartet

public class Prog_2_12 {  // Name im Buch: WarteAufThread

 public static void main(String[] args) {

  // Erzeugung und Start des Threads
  BeispielThread t = new BeispielThread();
  t.start();
  // Warten auf das Ende des Threads
  try {
   t.join();
  } catch (InterruptedException e) {}
  System.out.println("main(): Thread ist beendet");

 }

}
