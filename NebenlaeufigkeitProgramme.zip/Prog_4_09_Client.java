/* Beispielprogramm 4.9 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Kommunikation �ber Stream Sockets: Client */

import java.io.*;
import java.net.*;

public class Prog_4_09_Client {  // Name im Buch: StreamSocketClient

 public static void main(String args[]) throws java.io.IOException {

  Socket sock = new Socket("x1.x2.x3.x4",55555);
     // erster Parameter: numerische IP-Adresse des Servers
     
  // Nachricht an den Server schicken
  PrintStream outStream = new PrintStream(sock.getOutputStream());
  outStream.print("Hallo\0");
  
  // Antwort des Servers lesen
  DataInputStream inStream = new DataInputStream(sock.getInputStream());
  byte[] buf = new byte[256];
  inStream.read(buf);
  System.out.println("Client hat gelesen: "+(new String(buf)));
  
 }
 
}