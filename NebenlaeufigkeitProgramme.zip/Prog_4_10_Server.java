/* Beispielprogramm 4.10 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Kommunikation �ber Datagram Sockets: Server */

import java.io.*;
import java.net.*;

public class Prog_4_10_Server {  // Name im Buch: StreamSocketServer

 public static void main(String args[]) throws java.io.IOException {

  DatagramSocket sock = new DatagramSocket(55555);
            // Server-Socket mit beliebiger Portnummer zwischen 49152 und 65535
            
  // Nachricht des Clients empfangen
  byte[] buf = new byte[256];
  DatagramPacket packIn = new DatagramPacket(buf,buf.length);
  sock.receive(packIn);
  System.out.println("Server hat empfangen: "+new String(packIn.getData(),0,packIn.getLength()));
  
  // Antwort an Client zur�ckschicken
  InetAddress ipaddr = packIn.getAddress();
  int port = packIn.getPort();
  buf = "Nachricht ist angekommen".getBytes();
  DatagramPacket packOut = new DatagramPacket(buf,buf.length,ipaddr,port);
  sock.send(packOut);
  
 }
 
}