/* Beispielprogramm 2.14 aus                          */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Unterbrechung eines Threads mit interrupt() */

// Thread: Er gibt in einer Schleife einen Text wiederholt aus.
// Sobald von au�en die Methode interrupt() aufgerufen wird,
// verl�sst er die Schleife.

class BeispielThread extends Thread {

 public void run() {
   while (!isInterrupted())
    System.out.println("Hier ist der Thread");
 }
 
}

// Hauptprogramm: Erzeugt einen BeispielThread, blockiert sich f�r
// zwei Sekunden und terminiert den Thread dann wieder.

public class Prog_2_14 {  // Name im Buch: ThreadInterrupt

 public static void main(String[] args) {
 
  BeispielThread t = new BeispielThread();
  t.start();
  try {
    Thread.currentThread().sleep(2000);
  } catch (InterruptedException e) {}
  t.interrupt();
  System.out.println("Thread ist beendet");
 }
 
}
