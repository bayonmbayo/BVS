/* Beispielprogramm 3.6 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Ein Monitor f�r einen einfachen Ringpuffer */

import java.util.concurrent.*;

// Klasse f�r den Ringpuffer

class EinfacherRingpuffer {

 private int inhalt[];     // Werte, die im Puffer gespeichert sind
 private int schreibindex; // Index f�r die n�chste Schreiboperation

 // Konstruktor
 EinfacherRingpuffer(int kap) {
  inhalt = new int[kap];
  schreibindex = 0;
 }

 // Schreiben eines neuen Werts in den Puffer
 synchronized void schreiben(int wert) {
  inhalt[schreibindex] = wert;
  schreibindex = (schreibindex+1)%inhalt.length;
 }
 // Ausgabe des aktuellen Pufferinhalts auf den Bildschirm,
 // beginnend mit dem zuletzt geschriebenen Wert
 synchronized void ausgeben() {
  for (int i=schreibindex-1;i>=0;i--)
   System.out.print(" "+inhalt[i]);
  for (int i=inhalt.length-1;i>=schreibindex;i--)
   System.out.print(" "+inhalt[i]);
  System.out.println();
 }
}

// Schreib-Thread

class SchreibThread extends Thread {

 private EinfacherRingpuffer puf;
   // Puffer, in den der Thread Werte schreibt
   
 SchreibThread(EinfacherRingpuffer puf) {
  this.puf = puf; }
  
 public void run() {
  for (int i=0;i<20;i++) {
   puf.schreiben(i*10);
   try { sleep(500); } catch (InterruptedException e) { }
  }
 }
 
}

// Ausgabe-Thread

class AusgabeThread extends Thread {

 private EinfacherRingpuffer puf;
   // Puffer, dessen Werte der Thread ausgibt

 AusgabeThread(EinfacherRingpuffer puf) {
  this.puf = puf; }
  
 public void run() {
  for (int i=0;i<10;i++) {
   puf.ausgeben();
   try { sleep(500); } catch (InterruptedException e) { }
  }
 }
 
}

// Hauptprogramm

class Prog_3_06 {

 public static void main(String[] args) {
 
  // Erzeugung des Puffers
  
  EinfacherRingpuffer puf  = new EinfacherRingpuffer(5);
  
  // Erzeugung und Start zweier Threads
  // zum Schreiben in den Puffer bzw. zur Ausgabe seines Inhalts
  
  SchreibThread st = new SchreibThread(puf);
  AusgabeThread at = new AusgabeThread(puf);
  st.start();
  at.start();
  
 }
 
}