/* Beispielprogramm 4.2 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Kommunikation ueber benannte Pipes: Empfaenger */

#include <fcntl.h>
#include <stdio.h>

main() {

 char buffer[6];  /* Speicher fuer die empfangenen Daten */

 int fd;  /* Deskriptor fuer die Pipe */

 fd=open("PIPE_1",O_RDONLY);  /* Oeffnen der Pipe zum Lesen */

 read(fd,buffer,6);  /* Lesen von 6 Zeichen aus der Pipe */

 printf("Gelesen: %s\n",buffer);  /* Ausgabe hier: HALLO */

 unlink("PIPE_1");  /* Loeschen der Pipe */

}