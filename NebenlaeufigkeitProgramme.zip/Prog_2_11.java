/* Beispielprogramm 2.11 aus                          */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Erzeugung und Start zweier Threads */

// Klasse f�r die Threads dieses Beispiels: Ein Thread
// dieser Klasse gibt dreimal hintereinander einen Text aus,
// wobei er zwischen zwei Ausgaben jeweils eine Sekunde pausiert.

class BeispielThread extends Thread {

 private String ausgabetext;  // auszugebender Text

 // Konstruktor, der den Ausgabetext setzt
 BeispielThread(String ausgabetext) {
  this.ausgabetext = ausgabetext;
 }

 // run() definiert den Code, den der Thread ausf�hren soll
 public void run() {
  for (int i=0; i<3; i++) {
   // Blockieren f�r eine Sekunde
   try {
    sleep(1000);
   } catch (InterruptedException e) {}
   // Ausgabe des Texts zusammen mit der ID des Threads
   System.out.println(
      "Thread "+Thread.currentThread().getId()+": "+ausgabetext);
  }
 }
 
}

// Klasse f�r das Hauptprogramm

class Prog_2_11 {   // Name im Buch: GrundlagenVonThreads

 public static void main(String[] args) {
 
  // Ausgabe der Thread-ID des Hauptprogramms
  System.out.println(
     "Hauptprogramm: Thread "+Thread.currentThread().getId());
     
  // Erzeugung zweier Threads mit unterschiedlichen Ausgabetexten
  BeispielThread t1 = new BeispielThread("AAA");
  BeispielThread t2 = new BeispielThread("   BBB");
  
  // Start der beiden Threads, die dann nebenl�ufig
  // jeweils ihre run()-Methode ausf�hren
  t1.start();
  t2.start();
  
 }
 
}
