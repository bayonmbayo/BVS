/* Beispielprogramm 3.5 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Durchsetzung einer Reihenfolge mit einem Semaphor */

import java.util.concurrent.*;

// Vorg�nger-Thread

class Vorgaenger extends Thread {

 private Semaphore sem;  // Semaphor, �ber den sich der Thread
                         // mit dem Nachfolger synchronisiert.
                         
 Vorgaenger(Semaphore sem) {
  this.sem = sem; }
  
 public void run() {
  System.out.println("Vorg�nger l�uft");
  try { sleep (2000); } catch (Exception e) { }
  System.out.println("Vorg�nger ist fertig");
  sem.release(); // Entblockierung des Nachfolgers
 }
 
}

// Nachfolger-Thread

class Nachfolger extends Thread {

 private Semaphore sem;  // Semaphor, �ber den sich der Thread
                         // mit dem Vorg�nger synchronisiert.
                         
 Nachfolger(Semaphore sem) {
  this.sem = sem; }
  
 public void run() {
  System.out.println("Nachfolger wartet");
  try {
   sem.acquire();  // Warten auf den Vorg�nger
  } catch (InterruptedException e) { }
  System.out.println("Nachfolger l�uft weiter");
 }
 
}

// Hauptprogramm

class Prog_3_05 {  // Name im Buch: ThreadReihenfolgeMitSemaphor

 public static void main(String[] args) {
 
  // Erzeugung des Semaphor-Objekts,
  // mit dem die Reihenfolgebedingung durchgesetzt wird
  
  Semaphore sem  = new Semaphore(0);
  
  // Erzeugung und Start zweier Threads,
  // die sich �ber den Semaphor synchronisieren
  
  Vorgaenger t1 = new Vorgaenger(sem);
  Nachfolger t2 = new Nachfolger(sem);
  t1.start();
  t2.start();
  
 }
 
}