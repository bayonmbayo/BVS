/* Beispielprogramm 4.9 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Kommunikation �ber Stream Sockets: Server */

import java.io.*;
import java.net.*;

public class Prog_4_09_Server {  // Name im Buch: StreamSocketServer

 public static void main(String args[]) throws java.io.IOException {

  ServerSocket sockAcc = new ServerSocket(55555);
            // Server-Socket f�r den Verbindungsaufbau
            // mit beliebiger Portnummer zwischen 49152 und 65535
  Socket sockComm = null;
           // Socket f�r die Kommunikation mit dem Client
           
  // Verbindungsaufbauwunsch des Clients engegennehmen
  try {
    sockComm = sockAcc.accept();
  } catch (IOException e) {
    System.out.println("Accept fehlgeschlagen");
    System.exit(-1); }
    
  // Nachricht des Clients lesen
  DataInputStream inStream = new DataInputStream(sockComm.getInputStream());
  byte[] buf = new byte[256];
  inStream.read(buf);
  System.out.println("Server hat gelesen: "+(new String(buf)));
  
  // Antwort zur�ckschicken
  PrintStream outStream = new PrintStream(sockComm.getOutputStream());
  outStream.print("Nachricht ist angekommen\0");
  
 }
 
}