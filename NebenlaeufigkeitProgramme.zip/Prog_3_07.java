/* Beispielprogramm 3.7 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Ein Monitor f�r einen unbegrenzten Puffer mit Lese- und Schreiboperationen */

import java.util.concurrent.*;
import java.util.*;

// Klasse f�r den Puffer

class Puffer {

 private LinkedList<Integer> speicher = new LinkedList<Integer>();
 
 // Schreiben eines neuen Werts in den Puffer
 synchronized void schreiben(int wert) {
  speicher.add(wert);
  // Benachrichtigung eines wartenden Threads (siehe lesen())
  notify();
 }
 
 // Lesen eines Werts aus dem Puffer
 synchronized int lesen() {
  // Blockierung, solange der Puffer leer ist
  while (speicher.size()==0)
   try {
    wait();
   } catch (InterruptedException e) { }
  return speicher.removeFirst();
 }
 
}

// Schreib-Thread

class SchreibThread extends Thread {

 private Puffer puf;
   // Puffer, in den der Thread Werte schreibt
   
 SchreibThread(Puffer puf) {
  this.puf = puf; }
  
 public void run() {
  for (int i=0;i<10;i++) {
   puf.schreiben(i*10);
   try { sleep(500); } catch (InterruptedException e) { }
  }
 }
 
}

// Lese-Thread

class LeseThread extends Thread {

 private Puffer puf;
   // Puffer, dessen Werte der Thread ausgibt

 LeseThread(Puffer puf) {
  this.puf = puf; }
  
 public void run() {
  for (int i=0;i<10;i++) {
   System.out.println("Gelesen: "+puf.lesen());
   try { sleep(500); } catch (InterruptedException e) { }
  }
 }
 
}

// Hauptprogramm

class Prog_3_07 {

 public static void main(String[] args) {
 
  // Erzeugung des Puffers
  
  Puffer puf  = new Puffer();
  
  // Erzeugung und Start zweier Threads
  // zum Schreiben in den Puffer bzw. zur Ausgabe seines Inhalts
  
  SchreibThread st = new SchreibThread(puf);
  LeseThread lt = new LeseThread(puf);
  st.start();
  lt.start();
  
 }
 
}