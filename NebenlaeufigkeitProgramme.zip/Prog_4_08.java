/* Beispielprogramm 4.8 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Erzeuger-Verbraucher-System mit Piped Streams */

import java.util.concurrent.*;
import java.io.*;

// Verbraucher-Thread: liest beliebig viele Werte aus einer Pipe

class Verbraucher extends Thread {

 private PipedInputStream pin; // Input-Stream, in dem die Daten aus der Pipe eintreffen
 
 Verbraucher(PipedInputStream pin) {
  this.pin = pin; }
  
 public void run() {
  while (true) {
   byte gelesen = -1; // zur Aufnahme des gelesenen Werts
   try {
     gelesen = (byte) pin.read(); // liest byte-Wert aus der Pipe
   } catch (IOException exc) {
      // Eine Exception wird insbes. ausgel�st, wenn der Erzeuger
      // terminiert und damit seinen PipedOutputStream gel�scht
      // hat. Damit terminiert auch der Verbraucher, indem er hier
      // per return aus seiner run()-Methode zur�ckkehrt.
     return; }
   System.out.println("Gelesen: "+gelesen);
  }
 }
 
}

// Erzeuger-Thread: schreibt die Werte 10, ..., 50 in eine Pipe

class Erzeuger extends Thread {

 private PipedOutputStream pout; // Output-Stream, �ber den die Daten in die Pipe gelangen
 
 Erzeuger(PipedOutputStream pout) {
  this.pout = pout; }
  
 public void run() {
  for (byte wert=10;wert<=50;wert+=10) {
   try {
     pout.write(wert);  // schreibt byte-Wert in die Pipe
   } catch (IOException exc) { }
   try { Thread.sleep(2000); } catch (Exception e) {}
                      // Verz�gerung bis zum n�chsten Senden
  }
 }
 
}

// Hauptprogramm

public class Prog_4_08 {  // Name im Buch: ErzeugerVerbraucherMitPipes

 public static void main(String[] args) throws java.io.IOException, InterruptedException  {
 
  // Zwei zusammengeh�rige Piped Streams erzeugen
  PipedInputStream pin = new PipedInputStream();
  PipedOutputStream pout = new PipedOutputStream(pin);
  
  // Kommunizierende Threads erzeugen und starten
  Erzeuger erzeuger = new Erzeuger(pout);
  Verbraucher verbraucher = new Verbraucher(pin);
  erzeuger.start();
  verbraucher.start();
  
 }
 
}