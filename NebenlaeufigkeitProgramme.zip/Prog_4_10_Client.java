/* Beispielprogramm 4.10 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Kommunikation �ber Datagram Sockets: Client */

import java.io.*;
import java.net.*;

public class Prog_4_10_Client {  // Name im Buch: StreamSocketClient

 public static void main(String args[]) throws java.io.IOException {

  DatagramSocket sock = new DatagramSocket(); // Client-Socket
  // DatagrammPacket zusammenstellen
  byte[] buf = new byte[256];
  buf = "Hallo".getBytes();
  InetAddress ipaddr = InetAddress.getLocalHost();
     // wenn der Server auf demselben Knoten wie der Client l�uft.
     // alternativ:
     // InetAddress ipaddr = InetAddress.getByName("xyz");
     // xyz = numerische oder symbolische IP-Adresse des Servers
  int port = 55555;
  DatagramPacket packOut = new DatagramPacket(buf,buf.length,ipaddr,port);
  
  // DatagramPacket abschicken
  sock.send(packOut);
  
  // Antwort der Servers empfangen
  buf = new byte[256];
  DatagramPacket packIn = new DatagramPacket(buf,buf.length);
  sock.receive(packIn);
  System.out.println("Client hat empfangen: "+ new String(packIn.getData(),0,packIn.getLength()));
  
 }
 
}