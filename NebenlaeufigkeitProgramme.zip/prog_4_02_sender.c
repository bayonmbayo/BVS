/* Beispielprogramm 4.2 aus                           */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Kommunikation ueber benannte Pipes: Sender */

#include <fcntl.h>

main() {

 int fd;  /* Deskriptor fuer die Pipe */

 mkfifo("PIPE_1",0666);  /* Erzeugung der benannten Pipe */

 fd=open("PIPE_1",O_WRONLY);  /* Oeffnen der Pipe zum Schreiben */

 write(fd,"HAL",3); /* Schreiben zweier Zeichenfolgen */
 write(fd,"LO",3);  /* in die Pipe (inkl. Stringendezeichen \0) */

}