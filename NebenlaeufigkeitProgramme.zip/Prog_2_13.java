/* Beispielprogramm 2.13 aus                          */
/* C. Vogt, Nebenlaeufige Programmierung, Hanser 2012 */

/* Gemeinsame Variable f�r mehrere Threads */

// Klasse f�r das Hauptprogramm und die gemeinsam benutzbare Variable

public class Prog_2_13 {    // Name im Buch: ThreadDatenDemo

 // Variable, die von mehreren Threads benutzt werden soll
 static int i = 1;
 
 // Hauptprogramm
 public static void main(String[] args) {
  // Erzeugung und Start zweier Threads
  Thread1 t1 = new Thread1();
  Thread2 t2 = new Thread2();
  t1.start();
  t2.start();
 }
 
}

// Thread 1: weist nach einer Sekunde der Variablen den Wert 2 zu

class Thread1 extends Thread {

 public void run() {
  try {
   sleep(1000);
  } catch (InterruptedException e) {}
  Prog_2_13.i = 2;
 }
 
}

// Thread 2: gibt sofort und nach zwei Sekunden den Wert von i aus

class Thread2 extends Thread {

 public void run() {
  System.out.println(Prog_2_13.i);  // Ausgabe: 1
  try {
   sleep(2000);
  } catch (InterruptedException e) {}
  System.out.println(Prog_2_13.i);  // Ausgabe: 2
 }
 
}
